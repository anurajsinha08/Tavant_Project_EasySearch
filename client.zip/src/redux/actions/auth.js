import api from "../../utils/api";
import { setAlert } from "./alert";
import {
  AUTH_ERROR,
  LOGIN_FAIL,
  LOGIN_SUCCESS,
  LOGOUT,
  REGISTER_FAIL,
  REGISTER_SUCCESS,
  USER_LOADED,
} from "./types";
import axios from "axios";
import jwt from "jwt-decode";

export const loadUser = () => async (dispatch) => {
  try {
    const mapToken = await api.post(
      "/api/security/oauth/token?grant_type=client_credentials&client_id=33OkryzDZsIB_uaY4S4Z3yIfGvi8GlPobxVhE_AtCH_FD31QAwVmIwbSBSwz5aIQoFluxZKYtm7wPhFTKh_IjzrjWoia1LP9PtQBTWPKBHwLs9KR8t_UKw==&client_secret=lrFxI-iSEg8Lo8eaBV6Ty51Ca1muJWiZx6poskxW3z2Wpd9b8b43PX5OyBFfMwaT6MpbW58z7dOg7xWeulknngriyib0LrC7jY2PgU6nZvugpkKiB7IKFeLAXn8_-ESV"
    );
    localStorage.setItem("mapToken", mapToken.data.access_token);

    const uname = jwt(localStorage.getItem("token"));
    console.log(uname.sub);

    const res = await api.get("/api/" + uname.sub);

    console.log(JSON.stringify(res.data));
    dispatch({
      type: USER_LOADED,
      payload: res.data,
    });
  } catch (err) {
    dispatch({
      type: AUTH_ERROR,
    });
  }
};

export const register = (username, email, password) => async (dispatch) => {
  const body = { username, email, password };
  try {
    // const res = await api.post("/users", formData);
    const res = await api.post("/api/signup", body);

    dispatch({
      type: REGISTER_SUCCESS,
      payload: res.data,
    });
    dispatch(login(username, password, 1));
    dispatch(setAlert("Registered Successfully", "success"));
    // dispatch(loadUser());
  } catch (err) {
    const errors = err.response.data.errors;

    if (errors) {
      errors.forEach((error) => dispatch(setAlert(error.msg, "danger")));
    }

    dispatch({
      type: REGISTER_FAIL,
    });
  }
};

export const login = (username, password, flag) => async (dispatch) => {
  const body = { username, password };
  try {
    // const res = await api.post("/auth", body);
    const res = await api.post("/login", body);
    let token = res.headers.authorization.substring(7);
    localStorage.setItem("token", token);

    dispatch({
      type: LOGIN_SUCCESS,
      payload: res.data,
    });
    dispatch(loadUser());
    if (flag == null) {
      dispatch(setAlert("Login Successfull", "success"));
    }
  } catch (err) {
    const errors = err.response.data.errors;

    if (errors) {
      errors.forEach((error) => dispatch(setAlert(error.msg, "danger")));
    }

    dispatch({
      type: LOGIN_FAIL,
    });
  }
};

export const logout = () => ({ type: LOGOUT });
