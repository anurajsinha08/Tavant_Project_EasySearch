const { createProxyMiddleware } = require("http-proxy-middleware");

module.exports = function (app) {
  app.use(
    "/api/security/oauth/token",
    createProxyMiddleware({
      target: "https://outpost.mapmyindia.com",
      changeOrigin: true,
    })
  );
  app.use(
    "/api/places/geocode",
    createProxyMiddleware({
      target: "https://atlas.mapmyindia.com",
      changeOrigin: true,
    })
  );
  app.use(
    "/api",
    createProxyMiddleware({
      target: "http://localhost:8080",
      changeOrigin: true,
    })
  );

  app.use(
    "/login",
    createProxyMiddleware({
      target: "http://localhost:8080",
      changeOrigin: true,
    })
  );
};
