import React, { useState, useRef, Fragment } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";
import { setAlert } from "../../redux/actions/alert";

const initialState = {
  houseNumber: "",
  houseName: "",
  city: "",
  state: "",
  pincode: "",
  district: "",
  street: "",
  locality: "",
};

const SearchBar = ({ setAlert }) => {
  const wrapperRef = useRef(null);
  // const config = {
  //   headers: { Authorization: `Bearer 314ca714-f5ef-4e94-96e3-fac5d367c1d6` },
  // };
  const config = {
    headers: { Authorization: `Bearer ` + localStorage.getItem("mapToken") },
  };

  const [addressResponse, setaddressResponse] = useState([]);
  const [selectedAddress, setselectedAddress] = useState({});

  const onChange = (e) => {
    setselectedAddress({ formattedAddress: e.target.value });
    axios
      .get(`/api/places/geocode?itemCount=5&address=` + e.target.value, config)
      .then((res) => {
        // console.log(res.data.copResults);
        setaddressResponse(res.data.copResults);
      });
    console.log(e.target.value);
  };

  const selectAddress = (address) => {
    console.log(address);

    setaddressResponse([]);
    setselectedAddress(address);
  };

  const addAddress = (e) => {
    e.preventDefault();
    const addressData = { ...initialState };
    for (const key in selectedAddress) {
      if (key in addressData) addressData[key] = selectedAddress[key];
    }
    console.log(selectedAddress.eLoc);
    axios.post("/api/add", selectedAddress).then((res) => {
      setAlert("Address added successfully", "success");
    });
  };

  return (
    <Fragment>
      <div className="w-75 ">
        <div>
          <input
            placeholder="Type to search"
            name="search"
            value={selectedAddress.formattedAddress}
            onChange={onChange}
            className="form-control"
          />
          <ul className="list-group text-dark">
            {addressResponse &&
              addressResponse.map((address) => (
                <li
                  className="list-group-item animate__fadeIn animate__animated"
                  onClick={() => {
                    selectAddress(address);
                  }}
                >
                  {address.formattedAddress}
                </li>
              ))}
          </ul>
        </div>
      </div>

      <div className="container w-75">
        <div className="login-content text-white">
          <form onSubmit={addAddress}>
            <div className="input-div one">
              <div className="i">
                <i className="fas fa-envelope"></i>
              </div>
              <div className="div">
                <input
                  className="input"
                  type="text"
                  placeholder="House Number"
                  name="houseNumber"
                  value={selectedAddress.houseNumber}
                />
              </div>
            </div>
            <div className="input-div pass">
              <div className="i">
                <i className="fas fa-envelope"></i>
              </div>
              <div className="div">
                <input
                  className="input"
                  type="text"
                  placeholder="Street"
                  name="street"
                  value={selectedAddress.street}
                />
              </div>
            </div>
            <div className="input-div pass">
              <div className="i">
                <i className="fas fa-envelope"></i>
              </div>
              <div className="div">
                <input
                  className="input"
                  type="text"
                  placeholder="Locality"
                  name="locality"
                  value={selectedAddress.locality}
                />
              </div>
            </div>
            <div className="input-div pass p-50 h-10">
              <div className="i">
                <i className="fas fa-envelope"></i>
              </div>
              <div className="div">
                <input
                  className="input"
                  type="text"
                  placeholder="City"
                  name="city"
                  value={selectedAddress.city}
                />
              </div>
            </div>
            <div className="input-div pass">
              <div className="i">
                <i className="fas fa-envelope"></i>
              </div>
              <div className="div">
                <input
                  className="input"
                  type="text"
                  placeholder="state"
                  name="state"
                  value={selectedAddress.state}
                />
              </div>
            </div>
            <div className="input-div pass">
              <div className="i">
                <i className="fas fa-envelope"></i>
              </div>
              <div className="div">
                <input
                  className="input"
                  type="text"
                  placeholder="Pincode"
                  name="pincode"
                  value={selectedAddress.pincode}
                />
              </div>
            </div>
            <input type="submit" className="btn btn-primary" value="Add" />
          </form>
        </div>
      </div>
    </Fragment>
  );
};

SearchBar.propTypes = {
  setAlert: PropTypes.func.isRequired,
};

const mapDispatchToProps = { setAlert };

// export default SearchBar;

export default connect(null, mapDispatchToProps)(SearchBar);
