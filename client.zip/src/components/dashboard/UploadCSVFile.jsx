import axios from "axios";
import { setAlert } from "../../redux/actions/alert";
import React, { Component } from "react";

class App extends Component {
  state = {
    // Initially, no file is selected
    selectedFile: null,
  };

  // On file select (from the pop up)
  onFileChange = (event) => {
    // Update the state
    this.setState({ selectedFile: event.target.files[0] });
  };

  // On file upload (click the upload button)
  onFileUpload = () => {
    // Create an object of formData
    const formData = new FormData();

    // Update the formData object
    formData.append("file", this.state.selectedFile, "file");

    return axios.post("/api/upload", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
  };

  // File content to be displayed after
  // file upload is complete
  fileData = () => {
    if (this.state.selectedFile) {
      return (
        <div className="text-dark">
          <p>File Name: {this.state.selectedFile.name}</p>
        </div>
      );
    } else {
      return (
        <div className="text-dark">
          <br />
          <h4>Choose before Pressing the Upload button</h4>
        </div>
      );
    }
  };

  render() {
    return (
      <div className="center">
        <div className="text-dark">
          <h1>Drop file to upload</h1>
        </div>

        <div className="dropzone">
          <img
            src="http://100dayscss.com/codepen/upload.svg"
            className="upload-icon"
          />
          <input
            type="file"
            name="file"
            className="upload-input"
            accept=".csv"
            onChange={this.onFileChange}
          />
          <div className="form-group">
            <button
              type="button"
              className="btn btn-primary"
              onClick={this.onFileUpload}
            >
              <i className="fa fa-fw fa-upload" />
            </button>
          </div>
        </div>

        {this.fileData()}
      </div>
      // {this.fileData()}
      // </div>
    );
  }
}

export default App;
