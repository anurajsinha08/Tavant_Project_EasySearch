import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import SearchBar from "./SearchBar";
import UploadCSVFile from "./UploadCSVFile";

export const Dashboard = ({ auth: { user } }) => {
  return (
    <section className="dashboard">
      {/* <div className="dark-overlay"> */}
      <div className="dashboard-inner">
        {/* <h1 className="medium text-primary">Search</h1> */}
        <SearchBar />
        <UploadCSVFile />
      </div>
      {/* </div> */}
    </section>
  );
};

Dashboard.propTypes = { auth: PropTypes.object.isRequired };

const mapStateToProps = (state) => ({ auth: state.auth });

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
