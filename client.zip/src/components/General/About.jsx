import React from "react";
import PropTypes from "prop-types";
import wave from "../../assets/img/wave.png";

const About = (props) => {
  return (
    <center>
      <div>
        {/* <img className="wave" src={wave}></img> */}
        <p className="fs-4 fst-italic text-center   text-wrap text-break">
          Easy search is a search engine to locate places within India. We are
          using the MapMyIndia Geocodng Api for searching. We have provided a
          facility to add addresses, accept multiple addresses from a CSV file
          and store them in the database. Every address that is stored in the
          database is validated using the MapMyIndia database.
        </p>
      </div>
    </center>
  );
};

About.propTypes = {};

export default About;
