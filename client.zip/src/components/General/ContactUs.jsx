import React, { Fragment, useState } from "react";
import PropTypes from "prop-types";
import contact from "../../assets/img/contact.png";
import { Link } from "react-router-dom";

const ContactUs = (props) => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const { name, email, phone, message } = formData;

  const onChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <Fragment>
      <center>
        <div className="container">
          <div className="login-content">
            <form onSubmit={onSubmit}>
              <img src={contact} />
              <h2 className="title">Contact US</h2>
              <div className="input-div one">
                <div className="i">
                  <i className="fas fa-user"></i>
                </div>
                <div className="div">
                  <input
                    className="input"
                    type="text"
                    placeholder="Name"
                    name="name"
                    value={name}
                    onChange={onChange}
                    required
                  />
                </div>
              </div>
              <div className="input-div one">
                <div className="i">
                  <i className="fas fa-envelope"></i>
                </div>
                <div className="div">
                  <input
                    className="input"
                    type="email"
                    placeholder="Email Address"
                    name="email"
                    value={email}
                    onChange={onChange}
                  />
                </div>
              </div>
              <div className="input-div pass">
                <div className="i">
                  <i className="fas fa-phone"></i>
                </div>
                <div className="div">
                  <input
                    className="input"
                    type="number"
                    placeholder="Contact Number"
                    name="phone"
                    value={phone}
                    onChange={onChange}
                  />
                </div>
              </div>
              {/* <div className="input-div pass">
              <div className="i">
                <i className="fas fa-sticky-note"></i>
              </div>
              <div className="div">
                <textarea
                  className="input"
                  type="text"
                  placeholder="Message"
                  name="message"
                  value={message}
                  onChange={onChange}
                  minLength="10"
                />
              </div>
            </div> */}
              <div className="form-control div" cols="50" rows="8">
                <textarea
                  type="text"
                  placeholder="Message"
                  name="message"
                  value={message}
                  onChange={onChange}
                  minLength="10"
                />
              </div>
              <input type="submit" className="btn btn-primary" value="Submit" />
              <div className="my-1">
                <Link to="/">Back</Link>
              </div>
            </form>
          </div>
        </div>
      </center>
    </Fragment>
  );
};

ContactUs.propTypes = {};
export default ContactUs;
