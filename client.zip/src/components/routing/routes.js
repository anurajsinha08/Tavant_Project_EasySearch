import React from "react";
import { Switch, Route } from "react-router-dom";
import Alert from "../common/Alert";
import Register3 from "../auth/Register3";
import Login3 from "../auth/Login3";
import Dashboard from "../dashboard/Dashboard";
import PrivateRoute from "./PrivateRoute";
import ContactUs from "../General/ContactUs";
import About from "../General/About";

const Routes = (props) => {
  return (
    <section>
      <Alert />
      <Switch>
        <Route exact path="/register" component={Register3}></Route>
        <Route exact path="/login" component={Login3}></Route>
        <PrivateRoute
          exact
          path="/dashboard"
          component={Dashboard}
        ></PrivateRoute>
        <Route exact path="/alert" component={Alert}></Route>
        <Route exact path="/contact" component={ContactUs}></Route>
        <Route exact path="/about" component={About}></Route>
      </Switch>
    </section>
  );
};

export default Routes;
