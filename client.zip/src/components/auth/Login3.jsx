import React, { Fragment, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Link, Redirect } from "react-router-dom";
import { login } from "../../redux/actions/auth";
import bg from "../../assets/img/bg.svg";
import avatar from "../../assets/img/avatar.svg";

export const Login3 = ({ login, isAuthenticated }) => {
  // Here we declare the state for formData
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });

  const { username, password } = formData;

  // Setting values to its field and setting/updating the formData
  const onChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = (e) => {
    e.preventDefault();

    login(username, password);
  };

  if (isAuthenticated) {
    return <Redirect to="/dashboard"></Redirect>;
  }

  return (
    <Fragment>
      <div className="container">
        <div className="img">
          <img src={bg} />
        </div>
        <div className="login-content">
          <form onSubmit={onSubmit}>
            <img src={avatar} />
            <h2 className="title">Log In</h2>
            <div className="input-div one">
              <div className="i">
                <i className="fas fa-user"></i>
              </div>
              <div className="div">
                <input
                  className="input"
                  type="text"
                  placeholder="UserName"
                  name="username"
                  value={username}
                  onChange={onChange}
                  required
                />
              </div>
            </div>
            <div className="input-div pass">
              <div className="i">
                <i className="fas fa-lock"></i>
              </div>
              <div className="div">
                <input
                  className="input"
                  type="password"
                  placeholder="Password"
                  name="password"
                  value={password}
                  onChange={onChange}
                  minLength="6"
                />
              </div>
            </div>
            <input type="submit" className="btn" value="Login" />
            <div className="my-1">
              Don't have an account?
              <Link to="/register">Sign Up</Link>
            </div>
          </form>
        </div>
      </div>
    </Fragment>
  );
};

Login3.propTypes = {
  login: PropTypes.func.isRequired,
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

const mapDispatchToProps = { login };

export default connect(mapStateToProps, mapDispatchToProps)(Login3);
